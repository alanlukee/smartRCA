package com.dev.smartApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
