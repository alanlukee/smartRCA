package com.dev.smartApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartAppApplication.class, args);
	}

}
