package com.dev.smartApp.repository;

import com.dev.smartApp.model.Issue;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface IssueRepository extends JpaRepository<Issue,Long>, JpaSpecificationExecutor<Issue> {

}
