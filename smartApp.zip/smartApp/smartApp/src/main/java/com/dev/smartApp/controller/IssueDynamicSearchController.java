package com.dev.smartApp.controller;

import com.dev.smartApp.model.Issue;
import com.dev.smartApp.service.IssueDynamicSearchService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/issues")
@CrossOrigin(origins = "http://localhost:4200")
public class IssueDynamicSearchController {

    @Autowired
    private final IssueDynamicSearchService issueDynamicSearchService;

    public IssueDynamicSearchController(IssueDynamicSearchService issueDynamicSearchService) {
        this.issueDynamicSearchService = issueDynamicSearchService;
    }
    @PostMapping("/search")
    public List<Issue> searchIssues(@RequestBody Map<String, Object> filters) {
        return issueDynamicSearchService.searchIssues(filters);
    }

}
