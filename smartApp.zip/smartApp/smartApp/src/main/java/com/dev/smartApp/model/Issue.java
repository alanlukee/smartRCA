package com.dev.smartApp.model;

import jakarta.persistence.*;

import java.util.concurrent.atomic.AtomicLong;

@Entity
public class Issue {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true)
    private String sprno;
    private String project;
    private String headline;
    private String description;
    private String status;
    private String reportedVersion;
    private String assignedTo;
    private String targetMilestone;
    private String resolvedVersion;

    private static final AtomicLong counter = new AtomicLong(1);

    // Generate unique SPR No before persisting
    @PrePersist
    public void generateSprno() {
        this.sprno = generateUniqueSprno();
    }

    private String generateUniqueSprno() {
        long count = counter.getAndIncrement();
        return String.format("SPR%06d", count);
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    // Getters and setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSprno() {
        return sprno;
    }

    public void setSprno(String sprno) {
        this.sprno = sprno;
    }

    public String getHeadline() {
        return headline;
    }

    public void setHeadline(String headline) {
        this.headline = headline;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getReportedVersion() {
        return reportedVersion;
    }

    public void setReportedVersion(String reportedVersion) {
        this.reportedVersion = reportedVersion;
    }

    public String getAssignedTo() {
        return assignedTo;
    }

    public void setAssignedTo(String assignedTo) {
        this.assignedTo = assignedTo;
    }

    public String getTargetMilestone() {
        return targetMilestone;
    }

    public void setTargetMilestone(String targetMilestone) {
        this.targetMilestone = targetMilestone;
    }

    public String getResolvedVersion() {
        return resolvedVersion;
    }

    public void setResolvedVersion(String resolvedVersion) {
        this.resolvedVersion = resolvedVersion;
    }
}
