package com.dev.smartApp.service;

import com.dev.smartApp.model.Issue;
import com.dev.smartApp.repository.IssueRepository;
import com.dev.smartApp.specification.IssueSearchSpecification;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class IssueDynamicSearchService {
    @Autowired
    private final IssueRepository issueRepository;

    public IssueDynamicSearchService(IssueRepository issueRepository) {
        this.issueRepository = issueRepository;
    }
    public List<Issue> searchIssues(Map<String, Object> filters) {
        Specification<Issue> spec = IssueSearchSpecification.filterIssues(filters);
        return issueRepository.findAll(spec);
    }

}
