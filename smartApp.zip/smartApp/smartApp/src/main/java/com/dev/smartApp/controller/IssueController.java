package com.dev.smartApp.controller;

import com.dev.smartApp.model.Issue;
import com.dev.smartApp.repository.IssueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/issues")
@CrossOrigin(origins = "http://localhost:4200")
public class IssueController {

    @Autowired
    private IssueRepository issueRepository;

    @PostMapping
    public Issue createIssue(@RequestBody Issue issue) {
        return issueRepository.save(issue);
    }
}
