package com.dev.smartApp.specification;

import com.dev.smartApp.model.Issue;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.jpa.domain.Specification;

import java.util.Map;

public class IssueSearchSpecification {
    public static Specification<Issue> filterIssues(Map<String, Object> filters)
    {
        return (Root<Issue> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) -> {
            Predicate predicate = criteriaBuilder.conjunction(); // Default to true (no filter)
            for (Map.Entry<String, Object> entry : filters.entrySet())
            {
                String key = entry.getKey();  // Field name (e.g., "sprNo", "status")
                Object value = entry.getValue(); // Field value (e.g., "12345", "Open")
                if (value != null && !value.toString().isEmpty())
                {
                    predicate = criteriaBuilder.and(predicate, criteriaBuilder.equal(root.get(key), value));
                }
            }

            return predicate;
        };
    }
}

