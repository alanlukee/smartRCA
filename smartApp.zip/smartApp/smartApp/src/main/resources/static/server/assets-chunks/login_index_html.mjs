export default `<!DOCTYPE html><html lang="en" data-beasties-container><head>
  <meta charset="utf-8">
  <title>UiSmartApp</title>
  <base href="/">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="icon" type="image/x-icon" href="favicon.ico">
<link rel="stylesheet" href="styles-5INURTSO.css"><style ng-app-id="ng">body[_ngcontent-ng-c190536083]{font-family:Poppins,sans-serif;display:flex;justify-content:center;align-items:center;height:100vh;background-color:#f4f4f4;margin:0}.login-container[_ngcontent-ng-c190536083]{width:320px;padding:20px;border:1px solid #ccc;border-radius:8px;box-shadow:2px 2px 10px #0000001a;background-color:#fff;text-align:center;position:absolute;top:50%;left:50%;transform:translate(-50%,-50%)}input[_ngcontent-ng-c190536083]{width:80%;padding:8px;border:1px solid #ccc;border-radius:6px;font-size:14px;display:block;margin:8px auto}button[_ngcontent-ng-c190536083]{width:85%;padding:12px;background-color:#007bff;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:16px;transition:.3s ease}button[_ngcontent-ng-c190536083]:hover{background-color:#0056b3}.error[_ngcontent-ng-c190536083]{color:red;margin-top:12px;font-weight:600}.success[_ngcontent-ng-c190536083]{color:green;margin-top:12px;font-weight:600}</style></head>
<body>
  <app-root ng-version="19.1.7" ng-server-context="ssg"><router-outlet></router-outlet><app-login _nghost-ng-c190536083><div _ngcontent-ng-c190536083 class="login-container"><h2 _ngcontent-ng-c190536083>Login</h2><form _ngcontent-ng-c190536083 novalidate class="ng-untouched ng-pristine ng-invalid"><input _ngcontent-ng-c190536083 type="text" name="username" placeholder="Username" required class="ng-untouched ng-pristine ng-invalid" value><input _ngcontent-ng-c190536083 type="password" name="password" placeholder="Password" required class="ng-untouched ng-pristine ng-invalid" value><button _ngcontent-ng-c190536083 type="submit">Login</button></form><!----><!----></div></app-login><!----></app-root>
<script src="polyfills-FFHMD2TL.js" type="module"></script><script src="main-SF4BJ5L7.js" type="module"></script>

</body></html>`;